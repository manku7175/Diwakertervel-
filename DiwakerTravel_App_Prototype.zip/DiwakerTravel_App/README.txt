DIWAKERTRAVEL APP PROTOTYPE

Mobile-first bus booking app prototype.
Includes route search, demo bus results, seat selection, passenger form, confirmation ticket, taxi/tour/support sections and PWA setup.

DEMO ONLY: Real-time buses/seats, payment, OTP login, cancellation/refund and operator APIs are not connected yet.

Before publishing, replace +910000000000 in index.html with the business phone/WhatsApp number.

Upload all files to GitHub Pages, open the site in Android Chrome, then Chrome menu > Add to Home screen.
